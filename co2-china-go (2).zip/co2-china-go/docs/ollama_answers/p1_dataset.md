# Prompt 1 – full answers (gemma4:e2b, same chat)

## Answer 1a

* **Country Name:** This tells you which country the data belongs to.
* **Country Code:** This is the official code used to identify the country (like CHN for China).
* **Indicator Name:** This describes exactly what the measurement is (e.g., total CO2 emissions).
* **Indicator Code:** This is a specific technical label for that exact type of data.
* **Year:** This shows the specific year the emissions data was recorded.
* **CO2\_Mt\_CO2e:** This is the actual amount of carbon dioxide emissions, measured in Megatonnes of CO2 equivalents.

**Definitions:**

* **Mt CO2e:** Stands for Megatonnes of Carbon Dioxide equivalents. This is a way to measure all greenhouse gases as if they were CO2.
* **LULUCF:** Stands for Land Use, Land Use Change, and Forestry. This accounts for emissions and removals that happen due to changes in land use (like forests).

## Answer 1b

1. Check for missing values (NaN or nulls) in the `CO2_Mt_CO2e` column to identify incomplete records.
2. Validate that the `Year` column contains valid integer values within the expected range (1970 to 2022).
3. Verify that the `CO2_Mt_CO2e` values are correctly formatted as numbers and are not corrupted by text strings.
4. Ensure temporal sequence by checking that the `Year` column is strictly increasing to prevent time-series errors.
5. Identify and flag duplicate rows based on the combination of `Country Name`, `Country Code`, and `Year`.
6. Check the plausibility of emissions data by flagging any negative CO2 values, which are physically impossible.
7. Verify that essential identification columns (`Country Name` and `Country Code`) are present and non-empty for every row.
8. Perform a range check on `CO2_Mt_CO2e` to flag values that are extremely high or unusually low compared to historical norms.
