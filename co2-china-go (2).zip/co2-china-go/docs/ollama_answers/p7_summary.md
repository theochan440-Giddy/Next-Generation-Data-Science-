# Prompt 7 – answers (gemma4:e2b)

## Answer 7a (period bullets)

* Emissions grew rapidly from 1,385 Mt in 1977 to 10,760 Mt in 2013.
* Growth slowed significantly after 2013, increasing by only 1.7% between 2014 and 2022.

## Answer 7b (forecast bullet)

2025 predictions range from 12,519 Mt (No growth) to 15,615 Mt (Fast growth).
