# Prompt 3 – answers (gemma4:e2b)

## Answer 3a (method, no code)

**Q1: Is this method correct for OLS?**
Yes. Solving the Normal Equations, $(X^T X)b = X^T y$, is a fundamental and mathematically correct approach to finding the Ordinary Least Squares (OLS) estimates. This method finds the coefficient vector $b$ that minimizes the sum of squared residuals (the differences between the predicted and actual values).

**Q2: Give 3 situations where this method can fail or be inaccurate.**
1. **Multicollinearity:** If your predictor variables (t and $t^2$) are highly correlated, the matrix $X^T X$ becomes ill-conditioned, making the solution highly sensitive and inaccurate. (Risk: High, especially with polynomial terms).
2. **Singular Matrix:** If $X^T X$ is singular (non-invertible), the system cannot be solved, and the regression fails completely. (Risk: Moderate, possible if columns are perfectly dependent).
3. **Numerical Instability:** Gaussian elimination with partial pivoting can still suffer from numerical instability, leading to inaccurate results, particularly if the matrix is poorly conditioned. (Risk: Low to Moderate, but present in custom implementations).

## Answer 3b (matrix-building code)

**Manual Calculation:**
Given X = [[1,0],[1,1],[1,2]] and y = [1,3,5] (k=2):

* X^T X = [[3, 3], [3, 5]]
* X^T y = [9, 13]

**Code Check:**
The code iterates through each row r and then calculates the required sums. The inner loop correctly computes the matrix product X^T X and the vector product X^T y.

Verdict: correct

## Answer 3c (test ideas)

1. **Test 1: Basic Linear Regression.**
   X: [[1, 1], [1, 2]]
   y: [1, 3]
   Expected: Intercept = 1.0, Slope = 2.0

2. **Test 2: Zero Slope Fit.**
   X: [[1, 0], [1, 0]]
   y: [5, 5]
   Expected: Intercept = 5.0, Slope = 0.0

3. **Test 3: Test for Singularity/Error.**
   X: [[1, 1], [1, 1]] (Perfect multicollinearity)
   y: [1, 2]
   Expected: Error (indicating a singular matrix).
