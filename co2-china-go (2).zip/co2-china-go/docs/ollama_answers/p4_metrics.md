# Prompt 4 – answers (gemma4:e2b). The first, long version of this prompt gave no output, so it was split into small steps.

## Answer 4a (errors and MAE)

1. Error 1: 10 - 12 = -2
2. Error 2: 20 - 18 = 2
3. Error 3: 30 - 30 = 0

4. Absolute Errors: |-2| = 2, |2| = 2, |0| = 0.

5. MAE: (2 + 2 + 0) / 3 = 4 / 3 ≈ 1.333

## Answer 4b (RMSE; a longer version asking for RMSE and MAPE together stopped after "1. Squared Errors")

1. Squared Errors: (-2)^2 = 4, (2)^2 = 4, (0)^2 = 0.
2. MSE: (4 + 4 + 0) / 3 = 8 / 3 ≈ 2.667.
3. RMSE: sqrt(2.667) ≈ 1.633.

## Answer 4c (MAPE)

1. Percentage Errors: (2/10 x 100) = 20.0%, (2/20 x 100) = 10.0%, (0/30 x 100) = 0.0%.
2. MAPE: (20.0 + 10.0 + 0.0) / 3 = 30.0 / 3 = 10.0%.

## Answer 4d (R2, steps 1-3; the reply stopped before steps 4 and 5)

1. Mean of Actual Values: (10 + 20 + 30) / 3 = 20.0.
2. Squared Deviations: (10 - 20)^2 = (-10)^2 = 100, (20 - 20)^2 = 0^2 = 0, (30 - 20)^2 = 10^2 = 100.
3. Sum of Squared Deviations (SS_total): 100 + 0 + 100 = 200.

## Answer 4e (R2, steps 4-5, sent as a follow-up)

1. Sum of Squared Errors (SS_error): (-2)^2 + (2)^2 + (0)^2 = 4 + 4 + 0 = 8.
2. R^2: 1 - 8 / 200 = 1 - 0.04 = 0.960.
