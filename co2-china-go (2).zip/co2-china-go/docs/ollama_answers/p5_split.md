# Prompt 5 – answers (gemma4:e2b). The model's thinking stopped before the final lines, so a short follow-up asked for the final answer only.

## Answer 5a

By time
This preserves the temporal order, preventing future data from leaking into the training set.

## Answer 5b

Train: 1970 to 2015
Test: 2016 to 2022
