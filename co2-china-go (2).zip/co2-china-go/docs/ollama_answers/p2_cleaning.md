# Prompt 2 – answers (gemma4:e2b)

## Answer 2a (crashes in the row-reading loop)

1. The line `yearText := strings.TrimSpace(row[yearCol])` will panic if `yearCol` is -1, as it attempts to access an index out of bounds in the `row` slice.
2. The line `valueText := strings.TrimSpace(row[valueCol])` will panic if `valueCol` is -1, as it attempts to access an index out of bounds in the `row` slice.
3. If the returned index from `columnIndex` is greater than or equal to the length of `row`, both lines will panic due to an index out of range error.

## Answer 2b (fixes)

1. Before attempting to access the row elements, check if `yearCol` and `valueCol` are valid indices (not -1).
2. You can check both indices before the loop starts to ensure you have valid column references.
3. Inside the loop, before accessing `row`, ensure that both `yearCol` and `valueCol` are non-negative and less than the length of `row`.

## Answer 2c (second half of Clean: duplicate/negative checks and gap loop)

No problems found.

## Answer 2d (two specific questions)

**QUESTION 1:** For the second row with a CO2 value of -5, the condition `if value < 0` will be true. Therefore, the counter `NegativeValues` will increase.

**QUESTION 2:** The gap loop will count the years from 2023 up to 2049, because the condition is strictly less than the end year (2050). This results in 27 years being added to `report.MissingYears`.
