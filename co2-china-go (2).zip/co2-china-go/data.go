package main

// data.go — Step 1 and 2: load the raw CSV, check it, and clean it.

import (
	"encoding/csv"
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

// Record is one cleaned row: one year of China's CO2 emissions.
type Record struct {
	Year int
	CO2  float64 // million tonnes of CO2 (Mt CO2e)
}

// QualityReport lists what the data check found, so it can be printed and saved.
type QualityReport struct {
	RawRows        int
	EmptyRows      int
	MissingValues  int
	BadNumbers     int
	DuplicateYears int
	NegativeValues int
	MissingColumns []string // required columns not found in the header
	MissingYears   []int
	Columns        []string
}

// LoadRaw reads the CSV file and returns the header and all rows as text.
func LoadRaw(path string) ([]string, [][]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, nil, err
	}
	defer f.Close()

	reader := csv.NewReader(f)
	reader.FieldsPerRecord = -1 // allow rows with a different number of fields (e.g. a blank last line)
	rows, err := reader.ReadAll()
	if err != nil {
		return nil, nil, err
	}
	if len(rows) == 0 {
		return nil, nil, fmt.Errorf("file is empty")
	}
	return rows[0], rows[1:], nil
}

// columnIndex finds a column by name (ignoring upper/lower case and spaces).
func columnIndex(header []string, name string) int {
	for i, h := range header {
		if strings.EqualFold(strings.TrimSpace(h), name) {
			return i
		}
	}
	return -1
}

// Clean turns the raw text rows into Records and reports every data-quality problem it finds.
func Clean(header []string, rows [][]string) ([]Record, QualityReport) {
	report := QualityReport{RawRows: len(rows), Columns: header}

	yearCol := columnIndex(header, "Year")
	valueCol := columnIndex(header, "CO2_Mt_CO2e")
	// a missing column would make row[-1] crash, so stop and report it instead
	for name, col := range map[string]int{"Year": yearCol, "CO2_Mt_CO2e": valueCol} {
		if col < 0 {
			report.MissingColumns = append(report.MissingColumns, name)
		}
	}
	if len(report.MissingColumns) > 0 {
		sort.Strings(report.MissingColumns)
		return nil, report
	}

	seen := map[int]bool{}
	var records []Record

	for _, row := range rows {
		// skip blank lines
		if len(row) == 0 || (len(row) == 1 && strings.TrimSpace(row[0]) == "") {
			report.EmptyRows++
			continue
		}
		// a short row would crash on row[yearCol] or row[valueCol]
		if len(row) <= yearCol || len(row) <= valueCol {
			report.MissingValues++
			continue
		}
		yearText := strings.TrimSpace(row[yearCol])
		valueText := strings.TrimSpace(row[valueCol])
		if yearText == "" || valueText == "" {
			report.MissingValues++
			continue
		}
		year, err1 := strconv.Atoi(yearText)
		value, err2 := strconv.ParseFloat(valueText, 64)
		// ParseFloat accepts "NaN" and "Inf" without an error, so reject them here too
		// a year far outside the data range would flood MissingYears with fake gaps
		if err1 != nil || err2 != nil || math.IsNaN(value) || math.IsInf(value, 0) || year < 1900 || year > 2100 {
			report.BadNumbers++
			continue
		}
		if seen[year] { // checked before negatives so a repeated year is always reported as a duplicate
			report.DuplicateYears++
			continue
		}
		if value < 0 {
			report.NegativeValues++
			continue
		}
		seen[year] = true
		records = append(records, Record{Year: year, CO2: value})
	}

	// sort by year and look for gaps
	sort.Slice(records, func(i, j int) bool { return records[i].Year < records[j].Year })
	for i := 1; i < len(records); i++ {
		for y := records[i-1].Year + 1; y < records[i].Year; y++ {
			report.MissingYears = append(report.MissingYears, y)
		}
	}
	return records, report
}

// Print shows the data-quality report in the terminal.
func (r QualityReport) Print(records []Record) {
	fmt.Println("=== Data quality check ===")
	fmt.Printf("Columns: %v\n", r.Columns)
	if len(r.MissingColumns) > 0 {
		fmt.Printf("Missing required columns: %v\n", r.MissingColumns)
	}
	fmt.Printf("Raw rows: %d | clean rows: %d\n", r.RawRows, len(records))
	fmt.Printf("Empty rows removed: %d\n", r.EmptyRows)
	fmt.Printf("Missing values: %d | bad numbers: %d | negative values: %d | duplicate years: %d\n",
		r.MissingValues, r.BadNumbers, r.NegativeValues, r.DuplicateYears)
	fmt.Printf("Missing years in the series: %v\n", r.MissingYears)
	if len(records) > 0 {
		fmt.Printf("Years covered: %d to %d\n", records[0].Year, records[len(records)-1].Year)
	}
	fmt.Println()
}
