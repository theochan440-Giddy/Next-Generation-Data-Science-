package main

// pipeline_test.go — checks that the core functions give correct answers.
// Run with:  go test -v

import (
	"math"
	"testing"
)

func near(a, b, tol float64) bool { return math.Abs(a-b) <= tol }

// The line fit must recover a straight line exactly: y = 2 + 3x.
func TestFitLineExact(t *testing.T) {
	var x, y []float64
	for v := 0.0; v < 10; v++ {
		x = append(x, v)
		y = append(y, 2+3*v)
	}
	line, err := FitLine(x, y)
	if err != nil || !near(line.Intercept, 2, 1e-9) || !near(line.Slope, 3, 1e-9) {
		t.Fatalf("expected intercept 2 and slope 3, got %+v (err %v)", line, err)
	}
	if !near(line.Predict(10), 32, 1e-9) {
		t.Fatalf("expected prediction 32, got %f", line.Predict(10))
	}
}

// Tiny example checked by hand: points (0,1), (1,3), (2,5) lie on y = 1 + 2x.
// With noise: (0,1), (1,2), (2,4) -> slope 1.5, intercept 0.8333...
func TestFitLineNoise(t *testing.T) {
	line, err := FitLine([]float64{0, 1, 2}, []float64{1, 2, 4})
	if err != nil || !near(line.Slope, 1.5, 1e-9) || !near(line.Intercept, 5.0/6, 1e-9) {
		t.Fatalf("expected slope 1.5 and intercept 0.8333, got %+v (err %v)", line, err)
	}
}

// Bad input must give an error, not nonsense.
func TestFitLineErrors(t *testing.T) {
	if _, err := FitLine([]float64{1}, []float64{1}); err == nil {
		t.Fatal("expected an error for a single point")
	}
	if _, err := FitLine([]float64{2, 2, 2}, []float64{1, 2, 3}); err == nil {
		t.Fatal("expected an error when all x values are the same")
	}
	if _, err := FitLine([]float64{1, 2}, []float64{1}); err == nil {
		t.Fatal("expected an error when x and y have different lengths")
	}
}

// Metrics checked against values worked out by hand.
// actual 10, 20, 30; predicted 12, 18, 30 -> errors -2, +2, 0
func TestEvaluate(t *testing.T) {
	m := Evaluate([]float64{10, 20, 30}, []float64{12, 18, 30})
	if !near(m.MAE, 4.0/3, 1e-9) || !near(m.RMSE, math.Sqrt(8.0/3), 1e-9) ||
		!near(m.MAPE, 10, 1e-9) || !near(m.R2, 0.96, 1e-9) {
		t.Fatalf("unexpected metrics %+v", m)
	}
}

// Cleaning must catch blank rows, missing values, bad numbers (including NaN and Inf) and duplicate years.
func TestClean(t *testing.T) {
	header := []string{"Year", "CO2_Mt_CO2e"}
	rows := [][]string{{"2001", "10"}, {""}, {"2002", ""}, {"2003", "abc"}, {"2001", "11"}, {"2005", "12"}, {"2004", "-5"},
		{"2006", "NaN"}, {"2007", "Inf"}}
	records, r := Clean(header, rows)
	if len(records) != 2 || r.EmptyRows != 1 || r.MissingValues != 1 || r.BadNumbers != 3 ||
		r.DuplicateYears != 1 || r.NegativeValues != 1 {
		t.Fatalf("unexpected cleaning result %+v, records %v", r, records)
	}
	if len(r.MissingYears) != 3 { // 2002, 2003 and 2004 are missing between 2001 and 2005
		t.Fatalf("expected 3 missing years, got %v", r.MissingYears)
	}
}

// Broken files must be reported, not crash the program (problems found in Gen AI prompt 2).
func TestCleanBrokenInput(t *testing.T) {
	// missing column: no crash, no records, column reported
	records, r := Clean([]string{"Year", "Value"}, [][]string{{"2001", "10"}})
	if len(records) != 0 || len(r.MissingColumns) != 1 || r.MissingColumns[0] != "CO2_Mt_CO2e" {
		t.Fatalf("missing column: records %v, report %+v", records, r)
	}
	header := []string{"Year", "CO2_Mt_CO2e"}
	// short row: counted as a missing value, no crash
	if _, r = Clean(header, [][]string{{"2001"}}); r.MissingValues != 1 {
		t.Fatalf("short row: %+v", r)
	}
	// repeated year with a negative value: reported as a duplicate
	if _, r = Clean(header, [][]string{{"2001", "10"}, {"2001", "-5"}}); r.DuplicateYears != 1 || r.NegativeValues != 0 {
		t.Fatalf("duplicate year: %+v", r)
	}
	// year far out of range: rejected, no fake missing years
	if _, r = Clean(header, [][]string{{"2022", "10"}, {"2500", "11"}}); r.BadNumbers != 1 || len(r.MissingYears) != 0 {
		t.Fatalf("out-of-range year: bad %d, missing years %d", r.BadNumbers, len(r.MissingYears))
	}
}

// Every year must fall into the right period.
func TestPeriodOf(t *testing.T) {
	cases := map[int]string{1970: "1970-1977 Pre-reform", 1978: "1978-2000 Reform and opening-up",
		2001: "2001-2013 WTO and industrial boom", 2014: "2014-2022 Slowdown and plateau"}
	for year, want := range cases {
		if got := PeriodOf(year); got != want {
			t.Fatalf("%d: expected %q, got %q", year, want, got)
		}
	}
}

// The real file must load with 53 clean years and no problems.
func TestRealData(t *testing.T) {
	header, rows, err := LoadRaw(rawFile)
	if err != nil {
		t.Fatal(err)
	}
	records, r := Clean(header, rows)
	if len(records) != 53 || records[0].Year != 1970 || records[52].Year != 2022 || len(r.MissingYears) != 0 {
		t.Fatalf("unexpected data: %d rows, report %+v", len(records), r)
	}
}

// The model on the real data must give the same coefficients as numpy.polyfit
// (checked in validation/crosscheck_numpy.py): intercept -459.9903, slope 1873.8353.
func TestRealModel(t *testing.T) {
	header, rows, err := LoadRaw(rawFile)
	if err != nil {
		t.Fatal(err)
	}
	records, _ := Clean(header, rows)
	line, results, err := TrainAndTest(records)
	if err != nil {
		t.Fatal(err)
	}
	if !near(line.Intercept, -459.9903, 1e-3) || !near(line.Slope, 1873.8353, 1e-3) {
		t.Fatalf("unexpected coefficients %+v", line)
	}
	if len(results) != 2 || !near(results[0].Test.MAPE, 2.24, 0.01) || !near(results[1].Test.MAPE, 26.31, 0.01) {
		t.Fatalf("unexpected test errors: %+v", results)
	}
}
