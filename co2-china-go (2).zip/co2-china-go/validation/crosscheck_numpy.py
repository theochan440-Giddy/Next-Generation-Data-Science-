"""Independent check of the Go regression using numpy.

Fits the same straight line on the training years (1970-2012) and compares the
intercept and slope with the ones printed by the Go program (docs/pipeline_output.txt).

Run from the project root:   python3 validation/crosscheck_numpy.py
Needs: numpy  (pip install numpy)
"""
import csv
import re
import numpy as np

TRAIN_END = 2012  # same split as testFromYear = 2013 in model.go

rows = list(csv.DictReader(open("data/raw/NGDS_CO2_China.csv")))
year = np.array([int(r["Year"]) for r in rows])
co2 = np.array([float(r["CO2_Mt_CO2e"]) for r in rows])
t = (year - 1970) / 10  # decades since 1970, same as the Go code
train = year <= TRAIN_END

slope, intercept = np.polyfit(t[train], co2[train], 1)  # polyfit gives the highest power first

# read the Go coefficients from the saved pipeline output
go_line = None
for line in open("docs/pipeline_output.txt"):
    m = re.match(r"\s+Linear trend\s+.*coefficients \[(.*)\]", line)
    if m:
        go_line = [float(x) for x in m.group(1).split()]

print(f"{'':<10} {'Go':>12} {'numpy':>12}")
print(f"{'intercept':<10} {go_line[0]:>12.4f} {intercept:>12.4f}")
print(f"{'slope':<10} {go_line[1]:>12.4f} {slope:>12.4f}")
ok = np.allclose(go_line, [intercept, slope], atol=1e-4)
print("\nALL MATCH (4 decimal places)" if ok else "\nMISMATCH")
