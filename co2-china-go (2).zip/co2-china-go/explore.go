package main

// explore.go — Step 3 (explore) and Step 4 (differences across years and periods).

import (
	"math"
	"sort"
)

// Summary holds simple descriptive statistics.
type Summary struct {
	Count             int
	Mean, Median, Std float64
	Min, Max          float64
	MinYear, MaxYear  int
}

// Describe calculates the summary statistics of the CO2 values.
func Describe(records []Record) Summary {
	s := Summary{Count: len(records), Min: math.Inf(1), Max: math.Inf(-1)}
	values := make([]float64, len(records))
	for i, r := range records {
		values[i] = r.CO2
		s.Mean += r.CO2
		if r.CO2 < s.Min {
			s.Min, s.MinYear = r.CO2, r.Year
		}
		if r.CO2 > s.Max {
			s.Max, s.MaxYear = r.CO2, r.Year
		}
	}
	s.Mean /= float64(len(values))
	for _, v := range values {
		s.Std += (v - s.Mean) * (v - s.Mean)
	}
	s.Std = math.Sqrt(s.Std / float64(len(values)-1)) // sample standard deviation

	sort.Float64s(values)
	n := len(values)
	if n%2 == 1 {
		s.Median = values[n/2]
	} else {
		s.Median = (values[n/2-1] + values[n/2]) / 2
	}
	return s
}

// YearRow is one year with the extra columns we calculate.
type YearRow struct {
	Year      int
	CO2       float64
	Change    float64 // change from the previous year (Mt)
	GrowthPct float64 // % change from the previous year
	Period    string
}

// PeriodOf groups each year into a period of China's economic history.
func PeriodOf(year int) string {
	switch {
	case year <= 1977:
		return "1970-1977 Pre-reform"
	case year <= 2000:
		return "1978-2000 Reform and opening-up"
	case year <= 2013:
		return "2001-2013 WTO and industrial boom"
	default:
		return "2014-2022 Slowdown and plateau"
	}
}

// AddFeatures calculates the yearly change, growth % and period for every year.
func AddFeatures(records []Record) []YearRow {
	rows := make([]YearRow, len(records))
	for i, r := range records {
		row := YearRow{Year: r.Year, CO2: r.CO2, Period: PeriodOf(r.Year)}
		if i > 0 {
			prev := records[i-1].CO2
			row.Change = r.CO2 - prev
			row.GrowthPct = (r.CO2 - prev) / prev * 100
		} else {
			row.Change, row.GrowthPct = math.NaN(), math.NaN() // no previous year for 1970
		}
		rows[i] = row
	}
	return rows
}

// PeriodStats summarises one period.
type PeriodStats struct {
	Name          string
	Years         int
	StartCO2      float64
	EndCO2        float64
	MeanCO2       float64
	AvgGrowthPct  float64 // average yearly growth (compound annual growth rate)
	TotalIncrease float64
}

// GroupByPeriod summarises the rows period by period, keeping their order.
func GroupByPeriod(rows []YearRow) []PeriodStats {
	var order []string
	groups := map[string][]YearRow{}
	for _, r := range rows {
		if _, ok := groups[r.Period]; !ok {
			order = append(order, r.Period)
		}
		groups[r.Period] = append(groups[r.Period], r)
	}

	var result []PeriodStats
	for i, name := range order {
		g := groups[name]
		// start from the year before the period (if there is one), so growth includes the first step
		start := g[0].CO2
		steps := len(g) - 1
		if i > 0 {
			prev := groups[order[i-1]]
			start = prev[len(prev)-1].CO2
			steps = len(g)
		}
		end := g[len(g)-1].CO2
		mean := 0.0
		for _, r := range g {
			mean += r.CO2
		}
		mean /= float64(len(g))
		cagr := (math.Pow(end/start, 1/float64(steps)) - 1) * 100
		result = append(result, PeriodStats{Name: name, Years: len(g), StartCO2: start, EndCO2: end,
			MeanCO2: mean, AvgGrowthPct: cagr, TotalIncrease: end - start})
	}
	return result
}
