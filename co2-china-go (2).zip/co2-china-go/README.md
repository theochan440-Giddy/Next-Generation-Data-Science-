# China CO2 Emissions: A Simple Data Pipeline and Regression in Go

**Author:** Rio
**Question:** How did China's CO2 emissions change from 1970 to 2022, and how well does a simple straight-line regression predict them?

## Data

| Item | Details |
|---|---|
| File | `data/raw/NGDS_CO2_China.csv` (provided by the lecturer) |
| Indicator | Carbon dioxide (CO2) emissions (total) excluding LULUCF (Mt CO2e), World Bank code `EN.GHG.CO2.MT.CE.AR5` |
| Coverage | China, one value per year, 1970–2022 (53 rows) |
| Unit | Million tonnes of CO2 (Mt) |

## How it works (6 steps, in `main.go`)

1. **Load** the CSV (`data.go`).
2. **Clean** it and print a data-quality report (`data.go`).
3. **Explore**: summary statistics and yearly growth (`explore.go`).
4. **Compare periods**: average growth in four periods of China's economic history (`explore.go`).
5. **Regression**: one straight line, `CO2 = b0 + b1 × t`, where t = decades since 1970 (`model.go`).
6. **Save** the processed CSV files (`main.go`).

**The model.** The line is fitted on 1970–2012 and tested on 2013–2022 (never shuffled, because the model must predict the future from the past). It is found with the simple least-squares formula: `slope = sum((x - meanX)(y - meanY)) / sum((x - meanX)²)` and `intercept = meanY - slope × meanX`. Scores: MAE, RMSE, MAPE and R². For comparison, a "naive" guess (next year = this year) is scored the same way; it is not a regression.

## Results

| Model (trained 1970–2012) | Test MAPE, 2013–2022 | Test R² |
|---|---|---|
| Naive: same as last year | **2.2%** | 0.78 |
| Linear regression | 26.3% | −18.4 |

- **Coefficients:** intercept −460, slope +1,874 Mt per decade, which is about **+187 Mt of CO2 every year**.
- Emissions grew **13.7×**, from 912 Mt (1970) to 12,519 Mt (2022), peaking at 12,552 Mt in 2021.
- Average yearly growth by period: pre-reform 6.2%, reform era 4.3%, **WTO boom 8.7%**, **2014–2022 only 1.7%**.
- A straight line adds the same amount every year (+187 Mt). Real emissions curved upward during the 2000s boom, so the line is too low: in 2022 it predicts 9,284 Mt but the real value is 12,519 Mt (about 3,000 Mt too low on average).
- R² is very negative (−18.4) because the test years vary little (10,750 to 12,552 Mt, after growth slowed), so even a 3,000 Mt error is huge next to that spread. A negative R² means the line does worse than simply guessing the average of the test years.
- The simple "same as last year" guess wins (2.2% error) because emissions changed only a little from one year to the next after 2013.

## Project structure

```
co2-china-go/
├── main.go              # runs the 6 steps and saves the CSVs
├── data.go              # load + clean + data-quality report
├── explore.go           # summary statistics, growth, periods
├── model.go             # straight-line regression + MAE, RMSE, MAPE, R²
├── pipeline_test.go     # 9 unit tests
├── data/
│   ├── raw/NGDS_CO2_China.csv
│   └── processed/       # outputs (CSV)
├── validation/crosscheck_numpy.py   # independent numpy check of the coefficients
├── docs/
│   ├── genai_prompt_log.md     # AI prompts, answers and validation
│   ├── prompts/                # the exact prompts sent to Ollama
│   ├── ollama_answers/         # the full answers from Ollama
│   ├── numpy_crosscheck_output.txt
│   ├── pipeline_output.txt     # terminal output of the run
│   └── test_output.txt         # unit test results
└── slides/co2_china_presentation.pptx
```

## How to run

Requires Go 1.21 or newer. No external packages. Run from the project folder.

```bash
go run .        # runs the pipeline and writes data/processed/*.csv
go test -v      # runs the 9 unit tests
```

## Processed datasets (`data/processed/`)

| File | Contents |
|---|---|
| `co2_china_clean.csv` | Cleaned yearly data + yearly change, growth %, period, train/test label |
| `period_summary.csv` | Start, end, mean and average growth for each economic period |
| `model_metrics.csv` | Train and test scores for the linear regression and the naive guess |
| `model_predictions.csv` | Actual vs predicted CO2 for every year |

## Validation

- 9 unit tests pass: the line fit on exact and noisy points, error cases, metrics checked by hand, cleaning rules, broken-file handling, periods, and the real data and coefficients.
- The coefficients match Python `numpy.polyfit` to 4 decimal places. Reproduce with `python3 validation/crosscheck_numpy.py` (saved output: `docs/numpy_crosscheck_output.txt`).
- AI answers were checked one by one. See `docs/genai_prompt_log.md`.

## Go compared with Python (what was harder)

| In Python | In Go |
|---|---|
| `pandas.read_csv` loads and types the table | `encoding/csv` gives only text: every number is converted by hand with `strconv`, and each conversion returns an error to check |
| `np.polyfit` fits the line | No built-in regression: the formula is written by hand (and tested against numpy) |
| Missing values are `NaN` and tools skip them | Go has no dataframe: bad rows are found and counted by my own `Clean` code. Also, `ParseFloat` accepts the text "NaN" and "Inf" as valid numbers, so these have to be rejected explicitly |
| A bad index raises a readable error | A missing column (index −1) or a short row crashes with a `panic`, so lengths must be checked first |
| Mixing int and float just works | Types never convert silently: `int` and `float64` must be converted by hand |
| Unused variables and imports are allowed | They are compile errors |
| Plotting with matplotlib | No plotting in the standard library: charts are made in the slides |

## Use of Generative AI

Claude helped plan the pipeline, draft the Go code and write the prompts. A local Ollama model (`gemma4:e2b`) was used to review code, check the maths and wording, and I tested each of its answers. Every prompt, answer, check and the mistakes I caught are in `docs/genai_prompt_log.md`.
