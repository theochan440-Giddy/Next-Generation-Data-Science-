package main

// model.go — Step 4: ONE regression model that predicts CO2 emissions.
//
// The model is a straight line:   CO2 = intercept + slope × t
// where t = decades since 1970 (so 1970 -> 0, 1980 -> 1, 2022 -> 5.2).
//
// Time-based split: train on 1970-2012, test on 2013-2022.
// We never shuffle the years, because the model must predict the future from the past.
//
// For comparison we also score a "naive" guess: next year = this year (no regression).

import (
	"errors"
	"math"
)

const testFromYear = 2013 // first year of the test set

// decades turns a year into "decades since 1970". Small numbers are easier to read.
func decades(year int) float64 { return float64(year-1970) / 10 }

// Line is a straight line: y = Intercept + Slope × x.
type Line struct{ Intercept, Slope float64 }

// Predict gives the y value for one x value.
func (l Line) Predict(x float64) float64 { return l.Intercept + l.Slope*x }

// FitLine finds the best straight line through the points (ordinary least squares).
//
//	slope     = sum((x - meanX) × (y - meanY)) / sum((x - meanX)²)
//	intercept = meanY - slope × meanX
func FitLine(x, y []float64) (Line, error) {
	if len(x) != len(y) || len(x) < 2 {
		return Line{}, errors.New("need at least 2 points, with the same number of x and y values")
	}
	n := float64(len(x))
	meanX, meanY := 0.0, 0.0
	for i := range x {
		meanX += x[i]
		meanY += y[i]
	}
	meanX /= n
	meanY /= n

	cross, spread := 0.0, 0.0
	for i := range x {
		cross += (x[i] - meanX) * (y[i] - meanY)
		spread += (x[i] - meanX) * (x[i] - meanX)
	}
	if spread == 0 {
		return Line{}, errors.New("all x values are the same, so no line can be fitted")
	}
	slope := cross / spread
	return Line{Intercept: meanY - slope*meanX, Slope: slope}, nil
}

// Metrics measures how close the predictions are to the actual values.
type Metrics struct {
	MAE, RMSE, MAPE, R2 float64
}

// Evaluate calculates MAE, RMSE, MAPE (%) and R².
func Evaluate(actual, predicted []float64) Metrics {
	n := float64(len(actual))
	mean := 0.0
	for _, a := range actual {
		mean += a
	}
	mean /= n

	var m Metrics
	ssRes, ssTot := 0.0, 0.0
	for i := range actual {
		e := actual[i] - predicted[i]
		m.MAE += math.Abs(e)
		m.RMSE += e * e
		m.MAPE += math.Abs(e / actual[i])
		ssRes += e * e
		ssTot += (actual[i] - mean) * (actual[i] - mean)
	}
	m.MAE /= n
	m.RMSE = math.Sqrt(m.RMSE / n)
	m.MAPE = m.MAPE / n * 100
	m.R2 = 1 - ssRes/ssTot
	return m
}

// Result stores one model's predictions and scores.
type Result struct {
	Name, Formula string
	Predictions   map[int]float64 // year -> predicted CO2
	Train, Test   Metrics
}

// TrainAndTest fits the line on the training years and scores it and the naive guess.
func TrainAndTest(records []Record) (Line, []Result, error) {
	var x, y []float64
	for _, r := range records {
		if r.Year < testFromYear { // training rows only
			x = append(x, decades(r.Year))
			y = append(y, r.CO2)
		}
	}
	line, err := FitLine(x, y)
	if err != nil {
		return Line{}, nil, err
	}

	linear := map[int]float64{}
	naive := map[int]float64{}
	for i, r := range records {
		linear[r.Year] = line.Predict(decades(r.Year))
		if i > 0 {
			naive[r.Year] = records[i-1].CO2 // last year's value
		}
	}
	results := []Result{
		score("Naive (last year)", "CO2(t) = CO2(t-1)", naive, records),
		score("Linear trend", "CO2 = b0 + b1*t", linear, records),
	}
	return line, results, nil
}

// score compares the predictions with the actual values, for the train and test years.
func score(name, formula string, predictions map[int]float64, records []Record) Result {
	var trainA, trainP, testA, testP []float64
	for _, r := range records {
		p, ok := predictions[r.Year]
		if !ok {
			continue
		}
		if r.Year < testFromYear {
			trainA, trainP = append(trainA, r.CO2), append(trainP, p)
		} else {
			testA, testP = append(testA, r.CO2), append(testP, p)
		}
	}
	return Result{Name: name, Formula: formula, Predictions: predictions,
		Train: Evaluate(trainA, trainP), Test: Evaluate(testA, testP)}
}
