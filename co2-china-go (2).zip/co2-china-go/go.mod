module co2china

go 1.21
