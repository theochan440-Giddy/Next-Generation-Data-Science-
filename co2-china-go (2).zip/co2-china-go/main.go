package main

// main.go — runs the whole pipeline, one step after another:
//   1. load  2. clean  3. explore  4. compare periods  5. regression model  6. save CSVs
//
// Run with:  go run .

import (
	"encoding/csv"
	"fmt"
	"log"
	"math"
	"os"
	"strconv"
)

const (
	rawFile      = "data/raw/NGDS_CO2_China.csv"
	processedDir = "data/processed"
)

func main() {
	// 1. Load
	header, rows, err := LoadRaw(rawFile)
	if err != nil {
		log.Fatal(err)
	}

	// 2. Clean and check quality
	records, report := Clean(header, rows)
	report.Print(records)
	if len(records) < 2 {
		fmt.Println("Not enough clean rows to analyse. Check the data quality report above.")
		os.Exit(1)
	}

	// 3. Explore
	s := Describe(records)
	fmt.Println("=== Summary statistics (Mt CO2) ===")
	fmt.Printf("Count %d | mean %.0f | median %.0f | std %.0f\n", s.Count, s.Mean, s.Median, s.Std)
	fmt.Printf("Lowest %.0f (%d) | highest %.0f (%d) | growth %.1fx\n\n",
		s.Min, s.MinYear, s.Max, s.MaxYear, records[len(records)-1].CO2/records[0].CO2)

	yearRows := AddFeatures(records)
	biggestRise, biggestFall := yearRows[1], yearRows[1]
	for _, r := range yearRows[1:] {
		if r.GrowthPct > biggestRise.GrowthPct {
			biggestRise = r
		}
		if r.GrowthPct < biggestFall.GrowthPct {
			biggestFall = r
		}
	}
	fmt.Printf("Fastest yearly growth: %d (%+.1f%%) | biggest fall: %d (%+.1f%%)\n\n",
		biggestRise.Year, biggestRise.GrowthPct, biggestFall.Year, biggestFall.GrowthPct)

	// 4. Differences across periods
	periods := GroupByPeriod(yearRows)
	fmt.Println("=== Periods ===")
	for _, g := range periods {
		fmt.Printf("%-36s %2d yrs | %6.0f -> %6.0f Mt | avg growth %5.1f%%/yr\n",
			g.Name, g.Years, g.StartCO2, g.EndCO2, g.AvgGrowthPct)
	}

	// 5. Regression model: train on the early years, test on the last ten
	line, results, err := TrainAndTest(records)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("\n=== Regression model (train 1970-%d, test %d-2022) ===\n", testFromYear-1, testFromYear)
	for _, r := range results {
		fmt.Printf("%-20s train MAPE %5.1f%% | test MAE %6.0f  RMSE %6.0f  MAPE %5.1f%%  R2 %6.2f\n",
			r.Name, r.Train.MAPE, r.Test.MAE, r.Test.RMSE, r.Test.MAPE, r.Test.R2)
	}
	fmt.Printf("  %-20s CO2 = b0 + b1*t  coefficients %v\n", "Linear trend",
		[]float64{round(line.Intercept, 4), round(line.Slope, 4)})
	fmt.Printf("The line adds %.0f Mt per decade, about %.0f Mt every year (t = decades since 1970).\n",
		line.Slope, line.Slope/10)

	// 6. Save processed data
	must(os.MkdirAll(processedDir, 0o755))
	saveClean(yearRows)
	saveGroups(periods)
	saveMetrics(results)
	savePredictions(records, results)
	fmt.Println("\nSaved processed CSV files to", processedDir)
}

// ---------- CSV helpers ----------

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func writeCSV(name string, rows [][]string) {
	f, err := os.Create(processedDir + "/" + name)
	must(err)
	defer f.Close()
	w := csv.NewWriter(f)
	must(w.WriteAll(rows))
}

// num formats a number; missing values (NaN) become an empty cell.
func num(v float64, decimals int) string {
	if math.IsNaN(v) {
		return ""
	}
	return strconv.FormatFloat(v, 'f', decimals, 64)
}

func round(v float64, decimals int) float64 {
	p := math.Pow(10, float64(decimals))
	return math.Round(v*p) / p
}

func splitOf(year int) string {
	if year >= testFromYear {
		return "test"
	}
	return "train"
}

func saveClean(rows []YearRow) {
	out := [][]string{{"year", "co2_mt", "change_mt", "growth_pct", "period", "split"}}
	for _, r := range rows {
		out = append(out, []string{strconv.Itoa(r.Year), num(r.CO2, 2), num(r.Change, 2), num(r.GrowthPct, 2),
			r.Period, splitOf(r.Year)})
	}
	writeCSV("co2_china_clean.csv", out)
}

func saveGroups(periods []PeriodStats) {
	out := [][]string{{"period", "years", "start_co2_mt", "end_co2_mt", "mean_co2_mt", "avg_growth_pct_per_year", "total_increase_mt"}}
	for _, g := range periods {
		out = append(out, []string{g.Name, strconv.Itoa(g.Years), num(g.StartCO2, 1), num(g.EndCO2, 1),
			num(g.MeanCO2, 1), num(g.AvgGrowthPct, 2), num(g.TotalIncrease, 1)})
	}
	writeCSV("period_summary.csv", out)
}

func saveMetrics(results []Result) {
	out := [][]string{{"model", "formula", "train_mae", "train_mape", "test_mae", "test_rmse", "test_mape", "test_r2"}}
	for _, r := range results {
		out = append(out, []string{r.Name, r.Formula, num(r.Train.MAE, 1), num(r.Train.MAPE, 2),
			num(r.Test.MAE, 1), num(r.Test.RMSE, 1), num(r.Test.MAPE, 2), num(r.Test.R2, 3)})
	}
	writeCSV("model_metrics.csv", out)
}

func savePredictions(records []Record, results []Result) {
	head := []string{"year", "actual_co2_mt", "split"}
	for _, r := range results {
		head = append(head, r.Name)
	}
	out := [][]string{head}
	for _, rec := range records {
		row := []string{strconv.Itoa(rec.Year), num(rec.CO2, 2), splitOf(rec.Year)}
		for _, r := range results {
			if p, ok := r.Predictions[rec.Year]; ok {
				row = append(row, num(p, 2))
			} else {
				row = append(row, "") // no prediction for the first year
			}
		}
		out = append(out, row)
	}
	writeCSV("model_predictions.csv", out)
}
